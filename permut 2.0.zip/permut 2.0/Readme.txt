THE PROGRAM PERMUT AND THE PROGRAM CpSSR BECOME ONLY ONE PROGRAM.
When you run the program you can choise if you want to use permut or CpSSR

Table of Contents
        1 README PERMUT
        2 README CpSSR
        3 VERSION
        4 HELP

1 README PERMUT
---------------
This program is based on the paper by Odile Pons
and R�my J. Petit (Genetics 1996, 144:1237-1245), on that of Burban et al. 1999, 
Mol Ecol 8, 1593-1602, and on a paper by Petit et al. in press in Forest Ecology and Management. 

It computes measures of diversity and differenciation from haploid 
population genetic data, when a measure of the distance between haplotypes is available,
and test whether the differentiation and diversity measures differ from the equivalent measures
that do not take into account the distances between haplotypes (ie, that consider all haplotypes 
equally divergent).

The source file should be an ASCII file 
(its name should have 8 characters maximum: 12345678.txt)
 and should include the following information:

First line : 
Number of cytotypes    Number of populations  Number of characters distinguishing 
the variants (for instance number of polymorphic fragments, or of polymorphic 
nucleotide sites).

The program asks for the number of permutations to be made.
see the example (\ExamplePermut\input.txt and \ExamplePermut\output.out).

Then follows the number of individuals having a given cytotype (column)
in a given population (row). 

Finally, and without interruption, provide the table of character states for
all haplotypes, where each line corresponds to one haplotype, and each column to a 
character.

No column should be empty (no missing haplotype) and each population (row) 
should be composed of AT LEAST 3 individuals!

The output file provides permutated values of Nst in a single row, and the value of the last 5% 
and last 1%. The mean of the permutated values is also given and should be close to the Gst value (by construction). 
To test if the observed Nst value is larger than the Gst, we count how many permutated values 
are larger than the observed Nst. If you have 5% of the permutated values greater than the 
observed value of Nst, then your test is not significant, otherwise it is and you know
the P-value. This is akin to testing if Gst = Nst.

2 README CpSSR:
--------------- 
It computes measures of diversity and differenciation from haploid 
population genetic data, when the difference in number of repeats between alleles is available,
and tests whether the differentiation and diversity measures differ from the equivalent measures
when the distances between haplotypes is not considered (ie, when all haplotypes are considered 
equally divergent). 

The source file should be an ASCII file 
(its name should have 8 characters maximum: 12345678.txt)
 and should include the following information:

First line : 
Number of cytotypes    Number of populations  Number of cpSSR loci.

The program asks for the number of permutations to be made.
see the example (\ExampleCpSSR\input.txt and \ExamplePermut\CpSSR.out).

The program is dimensionned for a maximum number of 65 haplotypes, 50 populations,and 20 loci. 
If you have more than this, you should ask me a new compiled version, specifying how many loci, 
populations and haplotypes you have. 

Then follows the number of individuals having a given haplotype (column)
in a given population (row). 

Finally, and without interruption, provide the table of length variant states for
all haplotypes, where each line corresponds to one haplotype, and each column to a 
character.

No column should be empty (no missing haplotype) and each population (row) 
should be composed of AT LEAST 3 individuals!

The output file provides permutated values of Rst in a single row, and the value of the last 5% 
and last 1%. The mean of the permutated values is also given and should be close to the Gst value
(by construction). 
To test if the observed Rst value is larger than the Gst, you count how many permutated values 
are larger than the observed Rst. If you have 5% of the permutated values greater than the 
observed value of Rst, then your test is not significant, otherwise it is and you know
the P-value. This is akin to testing if Gst = Rst. I usually go for a one-sided test 
(i.e. I test if Rst>Gst, and not Rst<>Gst).

3 VERSIONS
----------
*Fisrt Version;
08.03.2001
Parameters limitation size:
        the number of cytotypes is limited to 50 
        the number of populations is limited to 100
        the number of populations is limited to 40 
Turbo Pascal Program

*Version 1.0:
04/2005
No Parameters Limitation
New Graphical Interface.
Delphi Program.

*Version 2.0:
Fusion with CpSSR program.
New choice: Weight distances between haplotypes by their frequencis or not.

4 HELP
------
For therorical help: Remy.Petit@pierroton.inra.fr
For technical help: Frederic.Raspail@pierroton.inra.fr 
